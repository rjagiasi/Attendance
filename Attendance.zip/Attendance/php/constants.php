<?php
	
	define("DATABASE", "Attendance");

	define("SERVER", "localhost");

	define("PASSWORD", "123");

	define("USERNAME", "root");

?>
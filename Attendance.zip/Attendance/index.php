<?php
	header("location: php/index.php");
?>